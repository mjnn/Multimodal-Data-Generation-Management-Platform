"""OMS Multimodal SDK — Rosbag 多模态打标与融合向量。

Public API::

    from oms_multimodal import OmsMultimodalClient, ClipConfig, AcousticPanelConfig

    client = OmsMultimodalClient(taxonomy_path="oms_label_taxonomy.yaml")
    result = client.process_bag("rosbag/output.bag")
"""
from __future__ import annotations

__version__ = "0.3.0"

from .acoustic_panel import AcousticPanelConfig, PanelType, render_acoustic_panel
from .asr_client import AsrClient, AsrConfig
from .client import OmsMultimodalClient
from .resources import bundled_sdk_doc_path, bundled_taxonomy_path, resolve_taxonomy_path
from .config import BagProcessResult, ClientConfig, ClipConfig, OutputConfig
from .embedding_client import FusionEmbeddingClient
from .exceptions import ApiError, ConfigurationError, OmsMultimodalError, ParseError
from .omni_client import OmniLabelClient
from .pipeline import LabelEmbeddingPipeline, resolve_bags, write_jsonl
from .rosbag_parser import (
    AudioPayload,
    Clip,
    FramePayload,
    RosbagExtractor,
    TextPayload,
    TopicInfo,
    inspect_bag,
)
from .taxonomy import load_taxonomy, parse_label_json, taxonomy_prompt_block

__all__ = [
    "__version__",
    "AcousticPanelConfig",
    "ApiError",
    "AsrClient",
    "AsrConfig",
    "AudioPayload",
    "BagProcessResult",
    "bundled_sdk_doc_path",
    "bundled_taxonomy_path",
    "ClientConfig",
    "Clip",
    "ClipConfig",
    "ConfigurationError",
    "FramePayload",
    "FusionEmbeddingClient",
    "LabelEmbeddingPipeline",
    "OmsMultimodalClient",
    "OmsMultimodalError",
    "OmniLabelClient",
    "OutputConfig",
    "PanelType",
    "ParseError",
    "RosbagExtractor",
    "TextPayload",
    "TopicInfo",
    "inspect_bag",
    "load_taxonomy",
    "parse_label_json",
    "render_acoustic_panel",
    "resolve_bags",
    "resolve_taxonomy_path",
    "taxonomy_prompt_block",
    "write_jsonl",
]
