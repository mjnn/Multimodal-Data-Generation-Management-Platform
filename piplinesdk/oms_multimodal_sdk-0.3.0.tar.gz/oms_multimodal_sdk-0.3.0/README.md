# labeling_and_embedding_test / OMS Multimodal SDK

从 ROS1 rosbag 提取多模态数据（相机帧、音频、事件文本），调用阿里云 **Qwen-Omni** 做 OMS 场景理解与打标，调用 **qwen3-vl-embedding** 生成融合向量。

## 安装

```bash
# 开发模式（推荐）
pip install -e .

# 或仅安装依赖
pip install -r requirements.txt
```

## 快速开始（CLI）

```bash
cp .env.example .env   # 填入 DASHSCOPE_API_KEY、DASHSCOPE_WORKSPACE_ID

# 推荐：不依赖 PATH（Windows / Linux 通用）
python -m oms_multimodal inspect --bag rosbag/output.bag
python -m oms_multimodal run --bag rosbag/output.bag

# 若 pip Scripts 已在 PATH，也可直接用：
oms-multimodal inspect --bag rosbag/output.bag
```

> **Windows 提示**：若 `oms-multimodal` 提示「不是内部或外部命令」，说明 Python Scripts 目录未加入 PATH。请改用 `python -m oms_multimodal`，或将 `%LocalAppData%\Python\pythoncore-3.14-64\Scripts` 加入用户 PATH。

## 快速开始（SDK）

```python
from oms_multimodal import OmsMultimodalClient, ClipConfig, OutputConfig

client = OmsMultimodalClient(taxonomy_path="oms_label_taxonomy.yaml")
result = client.process_bag("rosbag/output.bag")
print(result.embedding_rows, result.label_rows)
```

## 文档

| 文档 | 说明 |
|------|------|
| **[docs/SDK.md](docs/SDK.md)** | **完整 SDK 文档（API 参考、配置、示例）** |
| [wiki/](wiki/README.md) | 架构、输出格式、Rosbag 约定 |

## 包结构

```
oms_multimodal/          # 可 pip install 的 SDK 包
  client.py              # OmsMultimodalClient 主入口
  config.py              # ClientConfig / ClipConfig / OutputConfig
  acoustic_panel.py      # 声学面板渲染
  embedding_client.py    # qwen3-vl-embedding
  omni_client.py         # Qwen-Omni 打标
  pipeline.py            # 流水线编排
  rosbag_parser.py       # Rosbag 解析
  cli.py                 # CLI 入口
```
